# Failure domains and actuator feasibility

C measures coolant at the same physical node, not radiator temperature. Its sensor
frontend alone consumes simulated physical temperature. Its independent ADC/reference,
calibration,gain,noise,quantization,clock phase and acquisition state are explicit.
Only runtime output/status and timestamps cross the detector boundary. Independence
is conditional on the modeled failure domain, not a claim of universal immunity.

| Domain | Physical interpretation | Attribution available from consistency alone |
|---|---|---|
| A | Primary conversion/calibration path | A versus correlated BC remains ambiguous |
| B | Original redundant conversion/calibration path | B versus correlated AC remains ambiguous |
| C | Diagnostic conversion/calibration path | C versus correlated AB remains ambiguous |
| AB | Original pair shares corrupted calibration/reference/service domain; C excluded | AB-versus-C cut, neither side proved healthy |
| ABC | Shared systematic/environmental bias across all three paths | No independent absolute reference; slow common drift remains redundancy-limited |
| AC / BC | Correlated calibration-service error touching those selected channels | Single-versus-pair ambiguity, despite independent ADC hardware |

Failure injection is confined to the frontend and does not provide diagnostic labels.
Ramps add signed increasing offsets, steps hold an offset, pulses are rectangular
finite offsets, stuck conversions hold the sampled output with continuing conversion
timestamps. C acquisition freeze holds the entire readout and timestamp. Global
abrupt events may leave short asynchronous sampling signatures; those are distinct
from observing a persistent global absolute error. Never infer global immunity.

Runtime patterns A|BC,B|AC,C|AB identify a disagreement cut, not the true failed set.
The first two can support a single-member candidate under a single-fault hypothesis,
but pair-fault alternatives are explicitly present here, so no confident member
identification is claimed. Main origin is SENSOR_CONTROL only under existing causal
precedence. Mutually separated readings force UNKNOWN when no earlier direct origin
is established. No majority vote declares C or either matching sensor healthy.

## Actuator audit (no extension)

src/actuators.c implements pump degradation as command times scale, and stuck fan
as zero realized command. At zero command their outputs coincide with a healthy
actuator. Shaft speed/current absent excitation cannot identify an efficiency/authority
loss. No winding-resistance,driver-electrical,continuity or open-load mechanism is
modeled for these fault semantics. Adding a status bit from the injection label
would be circular evidence. Existing fan self_test_gap explicitly reads active_mode;
it is therefore not a defensible independent idle observation and is NOT used.

Mutually exclusive feasibility classification of the historical93 initially idle
actuator cases: A electrically observable while idle0; B mechanically observable
while idle0; C observable after natural excitation43; D requiring diagnostic
excitation50; E remaining fundamentally unspecified/unavailable0. All50 historical
never-excited misses fall in D, not hidden electrical failures. Electrical root
causes cannot be inferred from the current authority-loss abstraction. Active
excitation is outside this task. Therefore A2/A3 and actuator telemetry do not exist.
Current pump/fan semantics and monitors remain unchanged. New campaign initial/
whole-window excitation is classified post-hoc, never supplied to detection.
