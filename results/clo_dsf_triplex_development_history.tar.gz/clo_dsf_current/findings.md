# Triplex observability development findings

**Not promoted: original-space validation89.32% is below the required95%. CURRENT stays unchanged.**

Third coolant chain: model-feasible. It measures the same physical coolant node through separate acquisition/ADC state, calibration bias, gain error, ADC-reference gain, noise process, quantization and sampling phase. It is not perfect and is not an oracle. Its frontend alone consumes physical temperature; inference receives only runtime readouts/status/timestamps. No new actuator observable was defensible for the modeled idle faults. No A2/A3 were implemented.

Development used1200 TRAIN,600 CALIBRATION,600 untouched VALIDATION simulations with16 disjoint physical/configuration families. Thresholds and provider parameters were fixed before TRAIN; there was no tuning or selection search. The validation lock was made after calibration. Same physical cases and observations feed A0 and A1; each physical case ran once. A0 matched frozen9f993587 full runtime state at all2,882,400 observations.

## Fair denominators

Original space includes faults affecting only A,B,AB plus the four other origins:384 validation faults. Expanded space includes C,AC,BC,ABC:480 faults. Both use the same120 benign runs. S1 sensor space is96 faults; S2 is192. These are different fault populations and must not be mixed with each other or with historical holdout percentages.

| Method / space | Detection | Wilson95 CI | Benign | Plant detection | Silent plant | Median/P95 latency(s) |
|---|---:|---:|---:|---:|---:|---:|
| A0 ORIGINAL | 320/384 (83.33%) | 79.28–86.73% | 0/120 | 153/170 | 17 | 0/32.44 |
| A0 EXPANDED | 361/480 (75.21%) | 71.16–78.86% | 0/120 | 174/208 | 34 | 0/41.80 |
| A1 ORIGINAL | 343/384 (89.32%) | 85.84–92.03% | 0/120 | 170/170 | 0 | 0/39.93 |
| A1 EXPANDED | 415/480 (86.46%) | 83.11–89.23% | 0/120 | 192/208 | 16 | 0.1/42.96 |

A1 precision100% in both spaces; recall89.32% original and86.46% expanded. Pre/same/post plant alarms122/30/18 original and123/43/26 expanded. P95 increases because the extension detects additional slow cases: among jointly detected cases, original-space12 faster/308same/0slower; expanded21faster/340same/0slower. Latency is conditional on detections; misses do not receive fabricated latencies.

## Sensor and regression subgroups

| A1 group | Detected |
|---|---:|
| A_only | 32/32 |
| B_only | 28/32 |
| C_only | 29/32 |
| AB_common | 32/32 |
| AB_slow | 8/8 |
| AB_steps | 12/12 |
| AB_pulses | 8/8 |
| ABC_global | 11/32 |
| ABC_slow | 0/8 |
| AC_correlated | 16/16 |
| BC_correlated | 16/16 |
| independent_slow | 24/24 |
| weak_steps | 64/72 |
| pulses | 35/40 |
| stuck | 13/20 |
| C_acquisition | 4/4 |
| S1_original_sensor | 92/96 |
| S2_expanded_sensor | 164/192 |
| effective_memory | 42/42 |
| dormant_memory | 26/30 |
| excited_actuator | 39/39 |
| initially_unexcited_actuator | 0/33 |

C-only breakdown: slow8/8,steps8/8,pulses6/8,stuck3/4,acquisition freeze4/4. This explicitly faults the added chain, rather than making it a trusted truth channel. A+B common-mode improves from10/32 to32/32:22 additional detections. Original S1 sensor detection improves69/96 to92/96 (95.83%); expanded S2 is164/192 (85.42%). A+B+C global slow drift remains0/8; the11/32 detected global cases have abrupt/absolute runtime signatures and do not establish immunity to global common-mode.

Memory68/72,effective42/42; timing72/72;communication72/72;actuator39/72—all unchanged from A0. No added actuator detections. All33 initially unexcited validation actuator faults remained unexcited and missed. Idle feasibility A/B/C/D/E=0/0/0/33/0 for those33 cases; historical initially-idle93 cases had0/0/43/50/0. These are authority-loss semantics, not electrically specified open circuits. Idle driver status derived directly from injection labels was deliberately excluded.

The new actuator subgroup is pump-degradation-only:18 of the prior24 actuator cells per family. Fan semantics were inspected and remain covered by regression, but this campaign does not support a new fan-specific performance claim. Memory cells emphasize stuck bits. These cohort limits, the large unexcited fraction, and the added diagnostic-component denominator are explicit; no distribution was changed after results to cross95%.

## Localization and attribution

Original first localization343/343 correct,expanded415/415 correct,zero first UNKNOWN and zero wrong-origin runs/samples. Runtime original99408/99408 localized correct,1/99409 UNKNOWN; expanded115823/115823 localized correct,1/115824 UNKNOWN. The latter is0.000863%. Main SENSOR_CONTROL localization must not be confused with identifying a failed sensor member. Runtime cuts A|BC,B|AC,C|AB retain single-versus-pair ambiguity: no matching pair is declared healthy. Member-level attribution is not confidently resolved by triplex consistency alone. All-mutually-disagree behavior is covered by the focused test and forces UNKNOWN absent earlier direct causal evidence.

## Paired ablation

Original space: both320,A0-only0,A1-only23,neither41; exact McNemar p=2.384185791015625e-7. Of23 gains,22are AB common-mode and1is B-only. Expanded: both361,A0-only0,A1-only54,neither65; p=1.1102230246251565e-16. No losses. This supports a paired detection improvement on this development cohort; it does not satisfy the95% retention requirement or constitute a final unseen result.

## Observability accounting

| Miss category | Original | Expanded |
|---|---:|---:|
| Algorithm-limited | 5 | 8 |
| Qualification-limited | 0 | 0 |
| Latency-limited | 0 | 0 |
| Redundancy-limited | 0 | 21 |
| Genuinely unobservable under current passive runtime evidence | 36 | 36 |

The36 passive-unobservable cases comprise33 never-excited actuator faults and3 dormant memory cases without positive runtime evidence. One other memory miss is conservatively algorithm-limited because some runtime evidence existed; no claim identifies its physical information content. AB has no remaining misses. ABC accounts for21 redundancy-limited misses, including8 weak steps; this label means absent independent differential reference, not proof that every abrupt global waveform has zero information. Pulses have4 algorithm-limited and1 redundancy-limited miss. The classification rules were registered before outcomes and use truth only post-hoc. No injected domain enters inference.

## Decision and limits

AB>=80% YES (100%); benign<=1% YES (0/120); zero wrong confident origins YES; timing/communication/effective-memory preserved YES; plant detection nondecreasing YES. Original>=95% NO;expanded>=95% NO. Triplex NOT retained; actuator telemetry NOT implemented/retained; NOT ready to freeze this extension for a new unseen. The retained classical runtime and GUI bytes remain unchanged.

Strongest finding: physically diverse sensing recovered22 AB common-mode misses and removed all17 original-space silent plant misses. Strongest remaining limitation: passive unexcited actuators and global common-mode redundancy limits prevent the overall target. No DS rule, global threshold, memory probe, or actuator logic was retuned.

Model scope: C lag is implemented but the registered cohort uses zero lag; robustness to substantial sensor lag is not validated. C benign noise/offset/gain/phase vary by group; large benign C-specific spikes were not separately modeled. There is no hardware validation of failure-domain independence. Wilson intervals are descriptive for this grouped deterministic cohort;0/120 benign has an upper Wilson95 bound about3.10%, not a demonstrated population false-alarm rate below1%.

## Reproducibility and integrity

HEAD `1bc6b12d970acc702dea62ad2507f5709a5254cc`; no commit/push or unseen. Registered UTC `2026-09-29T13:30:49.330328+00:00`; lock UTC `2026-09-29T13:34:21.614579+00:00`; validation start `2026-09-29T13:34:34.472162+00:00`.

All21250 protected existing source/header/historical-result/GUI files match task-start hashes. All23 former CURRENT files are preserved byte-for-byte in `results/clo_dsf_current_history.tar.gz`. Historical final unseen files remain unchanged and serve only as development/reference for this architecture.

Deterministic manifest SHA256 `1521a808adb035a070e1b074545fac8f06a89dd17074372fa778f41f332be75b`; reconstruct with `run_clo_dsf_triplex.design()` and the saved CSV writer. Full family profiles,seeds,sensor imperfections and injection configurations are generated there. Historical overlap audit checked6 manifest/registry sources with zero physical-profile overlap. Raw simulation CSVs were removed after scoring; no representative traces retained.

Build plumbing correction after validation: the initial default Makefile glob picked up the experimental sensor C model but does not link libm, causing unresolved exp/round. The model was moved from src/diagnostic_temperature.c to src/v7_3/diagnostic_temperature.c with IDENTICAL source bytes. Runner and focused test changed ONLY that path. No detector/model parameter or behavior changed, no campaign reran. Experimental modules are not linked into the retained production runtime. Regression then passed; initial runtime binary bytes were restored after build checks.

Regression:
```json
{
  "build": {
    "exit": 0
  },
  "python_compile": {
    "exit": 0
  },
  "full_tests": {
    "exit": 0
  },
  "diff_check": {
    "exit": 0
  },
  "legacy_cases": 48,
  "rtl_cases": 64,
  "unit_tests": 337
}
```

Original validation lock (source relocation mapping immediately below):
```json
{
  "locked_at": "2026-09-29T13:34:21.614579+00:00",
  "selection": "A1 fixed observability extension; no fitted parameters",
  "files": {
    "/home/leonskal/code/virtual-ecu-phd/scripts/run_clo_dsf_triplex.py": "cd77efff4973721d0eeab4114aa4235027f32ebc5052e2d46ee8479de9a6d178",
    "/home/leonskal/code/virtual-ecu-phd/src/diagnostic_temperature.c": "b4cd951328299da10fa5b4c0a504e79f9cf8a252b861304e38e77546be4e7be9",
    "/home/leonskal/code/virtual-ecu-phd/include/diagnostic_temperature.h": "6648da2b9e3904009d659c9bf6463813a10a80d9e7d3fe36dfa2ed71869e827d",
    "/home/leonskal/code/virtual-ecu-phd/src/v7_3/triplex_consistency.c": "be679e4184818f6c679ddb7af0dfe7d4d7342fa3eb76958f71ab06fa297f5bd4",
    "/home/leonskal/code/virtual-ecu-phd/include/triplex_consistency.h": "7570b35fefc6f24787a8e4dee0ac140f28a6a40d1fe23f233821bac9972da6df",
    "/home/leonskal/code/virtual-ecu-phd/src/v7_3/clo_dsf_revised.c": "5f10bea9f363c983ffc596aa2d1573a03391b84b2560e13ee3490764b5d7e1d7",
    "/home/leonskal/code/virtual-ecu-phd/include/clo_dsf_revised.h": "da31070cf6cff5036aeb0a18eaa89df8606873e2aa9abe8678a0c93aaffcadab",
    "/home/leonskal/code/virtual-ecu-phd/results/cross_layer_safety_v7_3_dev/revised.cfg": "6f62e972a27c765cae6a24daf9b7b98fb1513cd46fc226a128d87a6431e73ac7",
    "/home/leonskal/code/virtual-ecu-phd/results/clo_dsf_current/architecture_definition.md": "508afaecddc16d29a1f30b19c1a85a5a5a66f228e4dda421d399f7e13146bfed",
    "/home/leonskal/code/virtual-ecu-phd/results/clo_dsf_current/failure_domain_model.md": "ccf48c9c4d96511d846aadb4daaa27b5131ca269b8f3d3fa04deafe66276dbc4",
    "/tmp/clo-triplex/manifest.csv": "1521a808adb035a070e1b074545fac8f06a89dd17074372fa778f41f332be75b",
    "/home/leonskal/code/virtual-ecu-phd/scripts/report_clo_dsf_triplex.py": "68ccf0485c7c94d6333411ee84684ac70ed24f578d1241174a4dd8f4e62410a0",
    "/home/leonskal/code/virtual-ecu-phd/tests/test_triplex_observability.py": "e0a8ec5414e970a91d2fc343a479531f034294fcdffe89429a4838b9163424c7"
  }
}
```

Content-preserving build correction:
```json
{
  "reason": "Default Makefile glob includes top-level sources but does not link libm. Move experimental-only module out of the default runtime build; no algorithm changes.",
  "old": "src/diagnostic_temperature.c",
  "new": "src/v7_3/diagnostic_temperature.c",
  "identical_source_sha256": "b4cd951328299da10fa5b4c0a504e79f9cf8a252b861304e38e77546be4e7be9",
  "changes": {
    "scripts/run_clo_dsf_triplex.py": {
      "before": "cd77efff4973721d0eeab4114aa4235027f32ebc5052e2d46ee8479de9a6d178",
      "after": "32cc9dd07c89637b4cae16141043a172897adb2f80aa030fc8577f3744cc6070",
      "change": "source path only"
    },
    "tests/test_triplex_observability.py": {
      "before": "e0a8ec5414e970a91d2fc343a479531f034294fcdffe89429a4838b9163424c7",
      "after": "78f46dcd550dfa62837dc0c55a618688cdb5170fb7a18ebe53d36e1f7dd9bdb7",
      "change": "source path only"
    }
  }
}
```

Retention gates:
```json
{
  "original_at_least95": false,
  "expanded_at_least95": false,
  "AB_at_least80": true,
  "benign_at_most01": true,
  "zero_wrong": true,
  "plant_no_loss": true,
  "TIMING_preserved": true,
  "COMMUNICATION_preserved": true,
  "effective_memory_preserved": true,
  "retained": false
}
```
