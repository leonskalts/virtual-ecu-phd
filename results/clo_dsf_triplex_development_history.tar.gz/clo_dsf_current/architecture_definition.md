# Triplex coolant observability architecture and preregistered protocol

One 2400-case DEVELOPMENT campaign, no unseen or commit/push.16 distinct physical
families,150 simulations per family; TRAIN8families1200cases, CALIBRATION4families
600cases, VALIDATION4families600cases. Per family18MEMORY,18TIMING,18COMMUNICATION,
18ACTUATOR,48SENSOR_CONTROL,30BENIGN. The four non-sensor origins remain balanced.
Sensor emphasis is explicit and not chosen to achieve the95% target. Within sensor
space:8each A,B,C,AB,ABC and4each AC,BC. S1 original faults=A,B,AB only; S2 includes
all48sensor cells. Other origins belong to both overall denominators. Each600-case
partition thus contains384 original-space faults,480 expanded faults,120benign.

New physical profiles/seeds and group-wise separation. All families are disjoint
across partitions, including offsets/gains/noise/ADC references and acquisition
phases. Cell kinds recur, but complete configuration families never cross partitions.
Original templates supply valid memory/timing/communication/actuator semantics.
Sensor injection is a separate acquisition-boundary model shared identically by
A0 and A1: signed ramps,weak steps,rectangular pulses,stuck conversion output; C-only
also includes timestamp freeze. No detector reads injection configuration or truth.
C-only faults affect diagnostic coverage, not the control plant; report expanded
and original fault spaces separately. Never exclude common/global/unexcited cases.

C measures the SAME physical coolant quantity through its own gain,calibration
bias,noise PRNG,ADC reference gain,quantization,100ms schedule with independent
phase,acquisition/readout state. Optional first-order lag is implemented; the
registered cohort uses zero lag to isolate acquisition diversity (not a perfect
sensor:gain/offset/noise/quantization/phase remain nonzero). Physical interpolation
between simulator integration endpoints occurs only inside the sensor model.
Runtime inference sees only C output/status/timestamps and past C samples. A causal
linear projection over<=100ms aligns C to the A/B epoch; no future sample or plant
truth. Five consecutive qualified C readouts gate disagreement evidence.

A-B remains unchanged. A-C and B-C each reuse the EXACT existing FAST/SLOW code,
including .90C SLOW envelope,320samples,.40C FAST floor,1.2C/s bound,existing
same-sign integration and edge persistence. MAX of the three pair strengths feeds
ONE existing sensor evidence channel: do not count correlated pairs as independent
DS votes. No changes to global thresholds,reliabilities,classical fusion,temporal
fusion,memory/timing/communication/actuator providers or causal precedence.
Fresh explicit C failure or acquired C stale>200ms after startup is a new independent
acquisition-status contract,using the existing100ms cadence and two missed periods.
No active excitation or pre-mission BIST. A2/A3 do not exist (see failure-domain audit).

Member patterns are disagreement cuts:A|BC,B|AC,C|AB; each retains single-versus-pair
ambiguity. A matching pair never proves healthy. All mutually disagree outside the
existing .90C envelope => UNKNOWN main origin unless earlier direct non-sensor
causal evidence already exists. SENSOR_CONTROL domain evidence is otherwise causal
as before; no confident faulty-member claim. Pair pattern diagnostics are reported
separately from main origin. C is not a trusted oracle.

All parameters fixed before TRAIN. No parameter search; TRAIN and CALIBRATION are
feasibility/safety audits only. Freeze source/config/protocol hashes after CALIBRATION,
then run untouched VALIDATION once. Report even failures; no rescue tuning. Retain
only if original-space>=95%,ABcommon>=80%,benign<=1%,zero wrong confident samples,
no timing/communication/effective-memory loss,plant detection no worse. Also require
expanded-space>=95% to avoid exploiting the added sensor fault denominator. A0/A1
observe identical physical runs; default CURRENT production remains unchanged unless
all gates pass. Historical final evidence remains intact and is development/reference
knowledge for this new architecture, never reused as its final unseen evidence.

Alarm/propagation/latency metrics use existing collector semantics (post-onset rising
alarm edge; all-runtime localization includes pre-onset/benign samples). Independent
hidden counterfactual plant is used ONLY for post-hoc propagation scoring. Wilson
CIs are descriptive for a grouped deterministic design. Exact McNemar is descriptive.
Miss accounting precedence:global ABC=>redundancy-limited; actuator never excited or
memory no positive runtime evidence=>unobservable; no usable C qualification during
sensor episode=>qualification-limited; evidence first appears after horizon/onset
clearance constraints=>latency-limited where witnessed; otherwise algorithm-limited.
Accounting is post-hoc, not an inference feature. Avoid asserting absence of all
physical information from a low current provider score.

Storage:preserve superseded CURRENT artifacts byte-for-byte in a results-only archive
outside CURRENT, no duplicate source tree. CURRENT contains only requested7files,
with protocol/lock/manifest hashes embedded here. Deterministic manifest reconstructs
from the saved runner; no bulk traces; plan zero representative traces. Raw run CSVs
deleted immediately after scoring; temporary build and profiles removed after audit.

Registered UTC:2026-09-29T13:30:49.330328+00:00
Manifest SHA256:1521a808adb035a070e1b074545fac8f06a89dd17074372fa778f41f332be75b
History archive SHA256:67c75ae4d7ede0c0d604c5d63479d32da0002bbfa7bdfcded35cf47e76148e6f
