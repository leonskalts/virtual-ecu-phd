# Runtime provider audit

| Provider | Existing abnormal output | Qualified positive NORMAL observation | Ignorance / caveat |
|---|---|---|---|
| Timing | Deadline/execution age violation strength | Fresh completed runtime job within a period, release/completion provenance; q=positive deadline slack fraction | Missing/stale completion or no positive slack gives no health support |
| Communication | Acquisition-to-consumption timestamp mismatch, age/order violation | Same-tick valid acquisition, fresh delivery with identical timestamp, same-tick control consumption | No consumption, stale/unqualified transport: no health support |
| Memory diagnostic | Existing failed probe strength | Same-tick passing read/write/restore probe plus current shadow/register and consumed target agreement | No fresh probe or failed qualification: no health support; dormant faults are not forcibly alarmed |
| Calibration integrity | Existing trusted shadow/register/use mismatch | Part of the passing memory predicate; never a second correlated vote | Agreement alone without probe is insufficient to certify memory |
| Redundant FAST | Existing edge and bounded same-sign disagreement strength | Aligned independent readings, FAST valid, full SLOW history and qualified acquisition; instantaneous agreement inside existing .90C envelope | No reference, warmup, invalid timestamps/readings: no positive health |
| Redundant SLOW | Existing 320-sample disagreement mean strength | Above predicate times mean agreement inside existing .90C envelope | Same shared sensor source as FAST, not an extra independent vote |
| Acquisition/consumption and 300ms forecast | Existing continuous sensor response residual | No additional health vote; sensor agreement qualification above | Locally plausible common-mode response does not establish correctness against independent plant truth |
| Startup qualification | Existing five consecutive qualified acquisitions / established anomaly episode | A gate only, not a positive NORMAL source | Unqualified sensor anomaly suppressed exactly by existing startup rule; binary alarms also gated |
| Actuator command/response | Existing one-ULP command-to-actual violation strength | Each positively commanded pump/fan whose actual matches the existing clamp contract adds .5 to q | Zero command gives no health proof; no forced excitation or hidden degradation information |
| Plant temperature | Existing measured high-temperature evidence | None: ordinary temperature does not prove globally healthy operation | a=0 means pure ignorance; hidden physical temperature is never read |
| Causal precedence / origin | Existing qualified origin provenance and timestamps | Not a detection provider | Unchanged; newly detected cases without legacy confident origin remain UNKNOWN |

NORMAL is never the complement of anomaly: it additionally requires q>0.
Availability gates both masses. Benign TRAIN reliability discounts both equally
into ignorance. No injection metadata, future samples, profile identity, or fault
truth enters the C module. Post-hoc labels are used exclusively for scoring.
