# Binary-frame development findings

**Rejected; retained CURRENT remains classical. No unseen evaluation, commit, or push.**

A new 2400-case grouped campaign used TRAIN1200 (960fault/240benign), CALIBRATION600 (480/120), VALIDATION600 (480/120). All16 physical families are partition-disjoint. New profile hashes have zero overlap with audited historical manifests and the consolidated identity registry. Prior fusion development is preserved in previous_fusion_development.tar.gz; frozen final unseen artifacts are unchanged.

The representation uses qualified positive NORMAL as well as unchanged continuous ABNORMAL evidence. Inactive or unqualified providers give no health support. Six benign-TRAIN reliability values are all0.9842460800584412 (0/240 benign runs reached source strength0.5; Wilson upper bound supplies the discount). Identical BPAs feed B1 Dempster, B2 Yager, and B3 sequential binary PCR6. No new runtime observability.

CALIBRATION locked Pl(ABNORMAL)>=0.60 and bounded current-plus-two-past observations (discount0.8/0.64), with positive-A and existing startup gates. Historical NORMAL expires on new positive ABNORMAL support. B1 was nominated by the predeclared tie-break: all three rules detected427/480, benign0/120, and no losses versus B0 (422/480). No validation-based selection.

| Validation | Detection | Wilson95 CI | Benign | Plant detected | Silent | Median/P95 seconds | Wrong runs/samples |
|---|---:|---:|---:|---:|---:|---:|---:|
| B0 | 413/480 (86.04%) | 82.65–88.86% | 0/120 | 212/228 | 16 | 0/33.16 | 0/0 |
| B1 | 417/480 (86.88%) | 83.56–89.61% | 0/120 | 214/228 | 14 | 0/29.48 | 0/0 |
| B2 | 417/480 (86.88%) | 83.56–89.61% | 0/120 | 214/228 | 14 | 0/29.06 | 0/0 |
| B3 | 417/480 (86.88%) | 83.56–89.61% | 0/120 | 214/228 | 14 | 0/31.60 | 0/0 |

B1 precision100%, recall86.875%. Macro recall86.875% (balanced fault origins). Pre/same/post plant detection200/2/12; B0=186/14/12. Silent plant misses14 versus16. Empirical benign rate0% does not establish a population rate below1%: Wilson95 upper bound for0/120 is3.10%. Group-wise profiles also limit independent-binomial interpretations.

| B1 origin / subgroup | Detected |
|---|---:|
| MEMORY | 91/96 |
| TIMING | 96/96 |
| COMMUNICATION | 96/96 |
| SENSOR_CONTROL | 71/96 |
| ACTUATOR | 63/96 |
| weak_steps | 19/24 |
| pulses | 20/24 |
| effective_memory | 66/66 |
| dormant_memory | 25/30 |
| independent_slow | 32/32 |
| common_mode | 0/16 |
| excited_actuator | 44/44 |
| initially_unexcited_actuator | 19/52 |
| unexcited_throughout | 0/33 |

Dormant means no observed shadow/register corruption during the mission, not necessarily an undetectable probe condition:25/30 still failed active probes. The five missed dormant cases have finite500–900ms windows, four transient and one intermittent. Effective-memory detection66/66 is unchanged. Initially unexcited actuator detection19/52 comes from later excitation; all33 never-excited cases remain undetected.

## Conflict

K is the maximum pre-redistribution pairwise conflict over current-source and temporal combines per sample, using the fixed order. It is not a simultaneous all-source conjunctive K. The following uses every runtime sample, including pre-onset. Healthy channels can conflict with an abnormal different channel because their local health is projected into the global NORMAL hypothesis; substantial K is not proof of a faulty provider or independent evidence.

| B1 group | K median/P95/max | K>0.1 | K>0.3 | K>0.5 |
|---|---:|---:|---:|---:|
| ALL | 0/0.3494/0.5813 | 17.882% | 8.827% | 0.326% |
| weak_steps | 0/0/0.4743 | 0.205% | 0.097% | 0.000% |
| pulses | 0/0.3494/0.4743 | 26.513% | 26.363% | 0.000% |
| dormant_memory | 0/0.3494/0.3494 | 16.389% | 16.345% | 0.000% |
| common_mode | 0/0/0.01969 | 0.000% | 0.000% | 0.000% |
| excited_actuator | 0/0.4705/0.5746 | 31.275% | 30.895% | 2.818% |
| initially_unexcited_actuator | 0/0.4621/0.5744 | 12.723% | 11.907% | 1.110% |
| unexcited_throughout | 0/0/0 | 0.000% | 0.000% | 0.000% |

Explicit NORMAL creates genuine nonzero conflict, unlike the previous identically-zero detection frame. Most samples still have K0. Weak steps have brief conflict (P950); common-mode K remains very small and adds no useful independent reference. Full B1/B2/B3 distributions and origin breakdowns are in conflict_analysis.csv.

## Localization and paired result

No new origin classifier was introduced. A binary alarm inherits an origin only when the unchanged B0 frame independently provides a concurrent qualified alarm; otherwise UNKNOWN. B1 first detection:363 correct/417 detected (87.05%),54UNKNOWN,0wrong; among localized first detections363/363 correct. Runtime:131565/131565 localized samples correct,2829/134394UNKNOWN (2.105%), coverage97.895%,0wrong runs/samples. B0 first detection413/413 correct and runtime UNKNOWN652/134053 (0.486%). Thus confident-origin correctness is preserved, but first-detection and runtime coverage decrease. Sensor first-localization coverage is particularly reduced (17/71), because binary detection often precedes a qualified legacy origin. Localization before plant remains186 runs.

B1 versus B0: both413, legacy-only0, binary-only4, neither63. Exact two-sided McNemar p=0.125; insufficient evidence for a statistically supported detection-superiority claim. Added detections:3weak steps,1pulse; memory0,common-mode0,actuator0,other0. Lost0. B2/B3 have the same validation detected set and paired counts, with different latency and runtime alarm/localization trajectories.

## Interpretation and retention

1. Positive NORMAL evidence did create meaningful mathematical conflict.
2. The full binary redesign recovered four legacy misses. It did not demonstrate a special advantage for Yager or PCR6 over binary Dempster on validation.
3. Benefits were confined to weak sensor steps and one pulse.
4. Common-mode drift, never-excited actuators, and short dormant probe-phase gaps remain limits. Existing-information sensitivity also leaves five weak steps and four pulses missed.
5. Observability and origin logic were unchanged. The gain belongs to the combined representation, discounting, temporal guard, and decision mapping; it cannot be attributed solely to the combination rule. The fixed1/5 health scope assumption and remaining dependence between sources are modeling limitations.

Retention fails because86.875%<95%. Other specified gates pass:0/120 benign, plant detection214/228 no worse than212/228, zero wrong confident origins, timing96/96, communication96/96, effective memory66/66. No alternate rule is selected after validation. The experimental module stays unlinked from the production adapter for reproducibility; the current classical detector is retained. Not ready to freeze this rejected binary redesign for unseen validation.

Full regression passed:336tests, build, Python compile, diff check,48legacy cases,64RTL. All21248 protected pre-existing source/header/historical-result/GUI files match task-start hashes. B0 also matched frozen9f993587 full state at every one of2,882,400 campaign observations. GUI bytes preserved; its pre-existing Git modification remains. Historical final unseen results remain at their original hashes.

Artifacts: compact summaries, manifest, calibration grid/lock, audit and provider definitions; zero representative traces. Temporary simulator logs were deleted after each run; temporary mass arrays were deleted after scoring. No commit/push.
