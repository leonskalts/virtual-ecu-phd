# Binary examples and tests

Inactive source: a=0,q=0 => (N,A,U)=(0,0,1).
Fresh passing memory probe: a=0,q=1 => (.2,0,.8).
At reliability .5 that becomes (.1,0,.9).
Qualified source a=.7,q=1 => (.06,.7,.24); at r=.5 => (.03,.35,.62).
Unexcited actuator => no NORMAL. One commanded agreeing component => q=.5.

Contradictory simple supports A=.8,U=.2 and N=.8,U=.2 have K=.64.
Dempster gives N=A=.16/.36=4/9,U=1/9.
Yager gives N=A=.16,U=.68.
PCR6 gives N=A=.48,U=.04. These are genuinely distinct anomaly results.
For N=.3,A=.2,U=.5: Bel=.2,Pl=.7,binary BetP=.45.

The focused C test checks fresh versus stale probes, unexcited versus commanded
actuation, startup gating, discounting, all three decision quantities, nonnegative
normalized BPAs, genuine conflict for all three rules, short abnormal evidence after
100 normal observations, and finite expiry of bounded history. Prior operator tests
add random masses, total conflict, aliasing and precise Dempster delegation.
