# Binary-frame DEVELOPMENT protocol

Registered before outcomes. No unseen campaign. Frozen classical source9f993587
and all historical holdouts are development/reference knowledge; historical final
artifacts remain unchanged. B0 current legacy source is byte-checked against the
frozen source every runtime sample. No changes to plant, providers, memory probes,
FAST/SLOW sensors, Hybrid/HETIA, or origin/causal-precedence logic.

2400 simulations:16 physically distinct families,150 cases each (24 per fault
origin,30 benign). TRAIN families0–7:1200(960fault/240benign); CALIBRATION8–11:
600(480/120); VALIDATION12–15:600(480/120). Unique physical profiles and seeds;
no family/profile overlap. Cell templates preserve valid fault semantics and hard
subgroups, including finite difficult-phase memory, reference/primary/common-mode,
weak steps/pulses, cold/unexcited actuators and benign startup/noise/legal updates.
All cases count; no post-outcome exclusions. Historical identities preserved and
audited before manifest replacement. Wilson intervals describe this grouped design
and are not a claim of independent random sampling of a deployment population.

Explicit binary frame N,A,Theta. Continuous legacy positive anomaly strength a,
positive qualified health q from documented runtime predicates. Each source uses
mA=a; mN=(1-a)q/5; mTheta=1-mA-mN. Fixed1/5 scope factor reflects five origin
domains: local health cannot certify global health. This is an explicit modeling
assumption, not an empirically derived probability or fitted fault-dependent weight.
FAST/SLOW/forecast remain one correlated sensor source. No independent health mass
for plant-temperature level. Unavailable/unqualified/unexcited positive health=>q0.
Startup anomaly qualification remains unchanged. Reliability per source is
1 minus Wilson95 upper bound of benign TRAIN run fraction with a>=0.5. This uses
ONLY benign TRAIN and the prior fixed confirmed-strength boundary, no injected fault
labels or magnitudes. Apply Shafer discount identically to both singleton masses;
removed confidence becomes ignorance. Reliability values locked before CALIBRATION.

B1 classical Dempster,B2 Yager,B3 sequential binary PCR6(same as binary PCR5;
not simultaneous n-source PCR6). Identical discounted BPAs, source order timing,
communication,memory,sensor,actuator,plant. Origin always unchanged B0 origin frame.
New binary alarm inherits an origin only while B0 independently alarms with qualified
origin; otherwise UNKNOWN. Do not classify the faulty sensor member.

Temporal comparison:recursive existing0.8 discount versus bounded present+two past
fresh fused observations,discounts0.8,0.64. Both expire historical NORMAL into
ignorance when any current positive ABNORMAL support appears, retaining historical
ABNORMAL. This runtime-only anti-dilution guard prevents many past healthy samples
from overwhelming a fresh abnormal observation. No duration labels. Report the guard
as part of representation/temporal redesign, not just a change in fusion rule.

Decision grid shared across rules:Bel(A),Pl(A),logical binary BetP=A+Theta/2;
thresholds0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90,0.95,0.99,1.000001
(last is explicit no-alarm fallback). Require existing startup qualification and
positive A support: ignorance alone cannot alarm. TRAIN exploratory summaries;
CALIBRATION alone selects one metric,threshold,temporal policy with <=1% benign
alarm runs for EACH rule. Optimize minimum then summed fault recall across rules,
then total benign alarms. Tie order Bel,BetP,Pl; bounded,recursive;higher threshold.
Nominate best binary rule using CAL benign alarms,wrong samples,lost B0 detections,
silent misses,higher detection,tie B1,B2,B3. Freeze all science/config/selection and
manifest hashes before VALIDATION. No subsequent parameter or rule selection.

Conflict=max pre-redistribution pairwise K across six current combines and temporal
combines per observation; not an associative all-source conjunctive K. Record exact
sample distribution overall/per subgroup, median/P95/max and fractions K>0.1/.3/.5.
All runtime windows, including pre-onset, reported explicitly; rule dependence and
fixed source order acknowledged. Fault performance uses post-onset rising alarm
edges; pre-onset alarms and persistent alarms crossing onset are not credited as
new detections. Runtime localization counts ALL alarm samples including pre-onset.
Exact paired McNemar, descriptive without multiplicity adjustment; no discordance p1.

Retain nominated binary only if untouched VAL>=95% faults,<=1% benign,plant detection
no worse than paired B0,zero wrong confident samples/runs, and no timing,communication,
effective-memory losses. Otherwise leave CURRENT detector unchanged. No second search.
Temporary sufficient mass arrays only for calibration/replay; no repeated simulations.
Delete raw CSVs after each run and temporary arrays after final selected scoring.
Preserve compact previous development artifacts in one archive (no source tree),
new summaries/manifests/protocol. Max8 representative traces; plan zero.
