# Binary development validation record

Git HEAD: `1bc6b12d970acc702dea62ad2507f5709a5254cc`. Classical source reference: `9f9935876dd15a9668c76f3cd5634f77a2dde6ad`. No commits or pushes.

Protocol registered UTC: 2026-09-28T15:35:01.736733+00:00.
Selection locked UTC: 2026-09-28T15:39:31.061610+00:00. VALIDATION started UTC: 2026-09-28T15:40:14.429900+00:00.

One campaign2400cases; each physical simulation executed once. TRAIN replay applied its benign-fitted reliability to saved causal BPAs, not new simulations. CALIBRATION replay compared the registered decision grid. VALIDATION ran only after selection/hash lock; all fixed rules and the locked policy were scored. No post-validation scientific edits.

The replay routine has only time/qualification/legacy output and source masses, plus the benign-fitted reliability vector. It never receives origin, injected magnitude/type, profile identifier, future observation, or propagation truth. Full state equivalence asserts B0 versus frozen source every100ms across2,882,400 samples. Constructors assert BPA validity; replay asserts finite, normalized and nonnegative results.

Selected configuration: B1 Dempster; Pl(A)>=0.60; bounded temporal memory. Reliability0.9842460800584412 for all six sources. Candidate rejected; production/default adapter unchanged. Experimental binary module is not linked into the retained runtime build.

Protected existing files checked: 21248; changes0. Includes all historical result files outside CURRENT, Hybrid/HETIA/legacy source, and GUI bytes. Every one of14 selected scientific/config/report hashes unchanged.

Regression:
```json
{
  "build": {
    "exit": 0
  },
  "python_compile": {
    "exit": 0
  },
  "full_tests": {
    "exit": 0
  },
  "diff_check": {
    "exit": 0
  },
  "legacy_cases": 48,
  "rtl_cases": 64,
  "unit_tests": 336
}
```

Hash record (same before/after validation):

- `/home/leonskal/code/virtual-ecu-phd/src/v7_3/clo_binary_detection.c`: `c867be8c36d3453c1300a0e1d806367d740a155ad6771dfc58c2fde56a075d14`
- `/home/leonskal/code/virtual-ecu-phd/include/clo_binary_detection.h`: `775b156fce294e8dba85e84a4ac223df01716ac5ef792bf2bc2162968b3660f4`
- `/home/leonskal/code/virtual-ecu-phd/src/v7_3/clo_dsf_revised.c`: `5f10bea9f363c983ffc596aa2d1573a03391b84b2560e13ee3490764b5d7e1d7`
- `/home/leonskal/code/virtual-ecu-phd/include/clo_dsf_revised.h`: `da31070cf6cff5036aeb0a18eaa89df8606873e2aa9abe8678a0c93aaffcadab`
- `/home/leonskal/code/virtual-ecu-phd/include/clo_fusion_rule.h`: `0bb1dc42699bf112f445eb0890375900f77a78ce615bfe5a8aa8a74b2ddae205`
- `/home/leonskal/code/virtual-ecu-phd/scripts/run_clo_dsf_binary_development.py`: `6a50c8cec8398d058423ccfe22f49d70d0aaa1e6c2ba510c16be5786a6945ccf`
- `/home/leonskal/code/virtual-ecu-phd/results/cross_layer_safety_v7_3_dev/revised.cfg`: `6f62e972a27c765cae6a24daf9b7b98fb1513cd46fc226a128d87a6431e73ac7`
- `/home/leonskal/code/virtual-ecu-phd/results/clo_dsf_current/development_protocol.md`: `3cbf32a1fed4bc2617e1f7d23ad588f7a34eb87ebe112bb77fea6b679398b92c`
- `/home/leonskal/code/virtual-ecu-phd/results/clo_dsf_current/split_manifest.csv`: `922838645e8da6ed49aaa9bbdd4df97b017b64e09a5464d6ec73461818fbe93c`
- `/home/leonskal/code/virtual-ecu-phd/results/clo_dsf_current/reliability_record.json`: `ca9abdc468958454f61c6bc7e571ea78f60bf4460f94dfb534ea27c2d1544b87`
- `/home/leonskal/code/virtual-ecu-phd/scripts/report_clo_dsf_binary.py`: `ed943072632fbae493ccf2a7486d903845e67ea38bbc066fc87fb2c8a350a41a`
- `/home/leonskal/code/virtual-ecu-phd/tests/test_clo_binary_detection.py`: `f6956b245da8c35d0bcb0f1bcea60497e2a381bffb900435e54f4cfc9c93e221`
- `/home/leonskal/code/virtual-ecu-phd/results/clo_dsf_current/binary_frame_definition.md`: `d05a6f380d09a1d3638e3456b7faf586d7c0150580bd50071d0ea8110e93d514`
- `/home/leonskal/code/virtual-ecu-phd/results/clo_dsf_current/provider_bpa_table.md`: `62d3ed4423698bfa5138a342cbae70e4bf2c11f0fc8e91517fc2eab3d6e61688`

GUI preserved hash: `3fdf2d807ea8661def7e447ff32be0ccf46d70e160e28390bff81aeffbab957a`.

Previous fusion development evidence retained in previous_fusion_development.tar.gz; identities also exposed as previous_fusion_manifest_identities.csv. Frozen classical final unseen artifacts were neither modified nor relabeled. The overlap audit records input hashes before current manifest replacement.

No raw traces retained (0/8). Temporary mass arrays and experiment build/profile workspace removed only after summaries and hashes verified. Full regression logs remain in /tmp/clo-binary; reproducible test counts recorded here.
