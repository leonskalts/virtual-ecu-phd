# Experimental binary anomaly frame

Logical atoms N=NORMAL, A=ABNORMAL. Storage masks 1 and 62 partition the
existing 6-bit array; the latter is ONE logical detection atom. Theta=63.
Generic six-atom pignistic allocation is inappropriate: binary BetP(A)=A+U/2.

For each of six correlated provider groups, retain the old runtime anomaly
strength a in [0,1]. A qualified positive-health predicate supplies q in [0,1].
Undiscounted BPA: m(A)=a, m(N)=(1-a)q/5, m(Theta)=1-a-m(N).
The fixed 1/5 scope factor is a conservative modeling assumption: a local health
observation covers one of five origin domains, not a proof of global health.
It is not a measured probability. Unlike a, normal support is necessarily local;
the global binary abstraction loses this domain detail, an interpretive limitation.

Shafer discount r: m'(A)=r*m(A), m'(N)=r*m(N), m'(Theta)=1-r+r*m(Theta).
r uses only benign TRAIN false positive evidence frequency, with a Wilson upper
confidence bound. This calibrates alarm-like spurious evidence, not a universal
estimate of sensitivity or of conditional source independence. Source correlation
and repeated observations remain limitations; sensor FAST/SLOW/forecast are pooled.

All rules consume exactly the same sources. Dempster normalizes nonempty products
by 1-K; Yager transfers K to Theta; sequential binary PCR6 redistributes each
conflicting product proportionally to the originating masses. Binary PCR6 equals
binary PCR5 here; no claim of simultaneous multi-source PCR6. Canonical fixed order
is timing,communication,memory,sensor,actuator,plant,then temporal evidence.
Dempster total conflict returns vacuous per existing implementation.

Both temporal policies transfer historical NORMAL into ignorance whenever fresh
ABNORMAL support is positive, before temporal discount. Historical ABNORMAL is
retained. This avoids a long normal history suppressing a short positive violation.
Compare recursive .8 history against at most two nonrecursive previous observations
(.8 and .64); only one is selected. Historical health expiry is part of this redesign.

Alarm requires existing startup qualification, positive A, and the locked decision
quantity above the locked global threshold. No alarm from pure ignorance. Localization
remains exactly the existing legacy origin frame: inherit only a concurrent qualified
legacy alarm origin; otherwise UNKNOWN. No faulty sensor-member classification.
